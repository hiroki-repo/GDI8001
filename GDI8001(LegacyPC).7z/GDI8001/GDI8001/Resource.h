﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ で生成されたインクルード ファイル。
// GDI8001.rc で使用
//
#define IDC_MYICON                      2
#define IDD_GDI8001_DIALOG              102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_GDI8001                     107
#define IDI_SMALL                       108
#define IDC_GDI8001                     109
#define IDR_MAINFRAME                   128
#define ID_32771                        32771
#define G                               32772
#define ID_32773                        32773
#define IDM_HFT                         32774
#define IDM_GREENDSP                    32775
#define IDM_PCG                         32776
#define ID_DIPSW_N80                    32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_32781                        32781
#define ID_32782                        32782
#define ID_32783                        32783
#define ID_32784                        32784
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
